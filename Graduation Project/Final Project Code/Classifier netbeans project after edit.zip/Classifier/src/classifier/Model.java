package classifier;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author chaosprince
 */
public class Model {

    public static void SaveContent(String content) {
        content = content.toLowerCase();
        ArrayList<String> StopWords = lib.loadFile("/home/chaosprince/NetBeansProjects/Classifier/configuration/R_Workspace/stopwords.txt");
        String cleaned_content = lib.RemoveStopWords(content, StopWords);
        cleaned_content = lib.Remove_punctuations(cleaned_content);
        String stemmed_content = lib.Stemm(cleaned_content);
        saveFile(stemmed_content, "/home/chaosprince/NetBeansProjects/Classifier/configuration/R_Workspace/content.txt");
    }

    public static String getResult() {
        String result = lib.Run_Command("Rscript /home/chaosprince/NetBeansProjects/Classifier/configuration/Script.R");
        return (result);
    }

    private static void saveFile(String content, String dir) {
        try {
            FileWriter file = new FileWriter(new File(dir));
            file.write(content);
            file.flush();
            file.close();
        } catch (IOException e) {
            System.out.println("Error in saveFile" + e.getMessage());
        }
    }
}
